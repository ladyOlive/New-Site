<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = htmlspecialchars($_POST['nome']);
    $email = htmlspecialchars($_POST['email']);
    $mensagem = htmlspecialchars($_POST['mensagem']);

    $to = "mari20mso@gmail.com";
    $subject = "Mensagem de Contato - " . $nome;
    $body = "Nome: $nome\nE-mail: $email\n\nMensagem:\n$mensagem";

    $headers = "From: $email\r\n";
    $headers .= "Reply-To: $email\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

    if (mail($to, $subject, $body, $headers)) {
        echo "<p>Mensagem enviada com sucesso! Você será redirecionado para a página inicial.</p>";
        header("refresh:5; url=index.html");
    } else {
        echo "<p>Houve um erro no envio da mensagem. Tente novamente mais tarde.</p>";
    }
}
?>